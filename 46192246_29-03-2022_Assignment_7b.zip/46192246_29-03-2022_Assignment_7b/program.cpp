/********************************************
 *     FILENAME           :    program.c
 *
 *     DESCRIPTION        :    Assignment_7b
 *
 *     REVISION HISTORY   :
 *
 *     DATE                NAME              REFERENCE               REASON
 *     --------------------------------------------------------------------
 *     29-03-2022     Kushagra Upadhyay      Assignment_7b    ==============
 *
 *     Copyright © 2022 Capgemini Group  All Rights Reserved
 *
 *************************************************/
#include <bits/stdc++.h>
using namespace std;

/****************************
 *     CLASS NAME        :   VALIDATOR
 *
 *     DESCRIPTION       :   class with email attributes
 *
 *     PRIVATE MEMBERS   :   string username, string host, string domain
 *
 *     PROTECTED MEMBERS :
 *
 *     PUBLIC MEMBERS    :   void writeData(ofstream *fout)
 ****************************/
class VALIDATOR
{
private:
    string username;
    string host;
    string domain;

public:
    /****************************
     *     FUNCTION NAME    :   VALIDATOR (parameterized constructor)
     *
     *     DESCRIPTION      :   Initializes validator object
     *
     *     PARAMETERS       :   string username, string host, string domain
     *
     *     RETURNS          :   None
     ***************************/
    VALIDATOR(string username, string host, string domain)
    {
        this->username = username;
        this->host = host;
        this->domain = domain;
    }

    /****************************
     *     FUNCTION NAME    :   writeData
     *
     *     DESCRIPTION      :   prints valid emails in the out file
     *
     *     PARAMETERS       :   output file pointer
     *
     *     RETURNS          :   None
     ***************************/
    void writeData(ofstream *fout)
    {
        string email = this->username + "@" + this->host + this->domain;
        *fout << email << endl;
    }
};

/****************************
 *     FUNCTION NAME    :   checkUserName
 *
 *     DESCRIPTION      :   validates username
 *
 *     PARAMETERS       :   username
 *
 *     RETURNS          :   true/false
 ***************************/
bool checkUserName(string &username)
{
    if (username.size() == 0)
        return false;

    for (auto ch : username)
        if (isalnum(ch) == 0)
            return false;

    return true;
}

/****************************
 *     FUNCTION NAME    :   checkHost
 *
 *     DESCRIPTION      :   validates Host
 *
 *     PARAMETERS       :   host
 *
 *     RETURNS          :   true/false
 ***************************/
bool checkHost(string &host)
{
    if (host.size() == 0)
        return false;

    unordered_set<string> validHosts = {"gmail", "yahoo", "yandex", "outlook"};

    //* search for the hostname in validhosts vector
    if (validHosts.find(host) == validHosts.end())
        return false;

    return true;
}

/****************************
 *     FUNCTION NAME    :   checkDomain
 *
 *     DESCRIPTION      :   validates Domain
 *
 *     PARAMETERS       :   Domain
 *
 *     RETURNS          :   true/false
 ***************************/
bool checkDomain(string &domain)
{
    if (domain.size() == 0)
        return false;

    return domain == ".edu" or domain == ".com";
}

/****************************
 *     FUNCTION NAME    :   invalidEmail
 *
 *     DESCRIPTION      :   prints "invalid email" msg
 *
 *     PARAMETERS       :   email
 *
 *     RETURNS          :
 ***************************/
void invalidEmail(string &email)
{
    cout << endl
         << "Invalid email: "
         << "\"" << email << "\"" << endl;
}

/***************************************************
 *     FUNCTION NAME    :   main
 *
 *     DESCRIPTION      :   DRIVER FUNCTION
 *
 *     PARAMETERS       :   ==============
 *
 *     RETURNS          :   EXIT_SUCCESS -- successfull termination
                            EXIT_FAILURE -- program failed
 *
 ********************************************************/
int main()
{
    //* ******* define variables and file streams ******** */
    string email;
    vector<VALIDATOR> valid_email_store; //? to store valid emails
    ifstream fin;
    ofstream fout;

    // ******** open file ******** */
    fin.open("in.txt");
    //! Error check
    if (fin.fail())
    {
        cerr << "Could not open input.txt\n";
        exit(EXIT_FAILURE);
    }

    fout.open("out.txt", ios_base::out);
    //! Error check
    if (fout.fail())
    {
        cerr << "Could not open output.txt\n";
        exit(EXIT_FAILURE);
    }

    while (fin >> email)
    {
        string username;
        string host;
        string domain;
        int atIndex;
        int dotIndex;
        int domainIdx;

        //&  ***************** USERNAME ******** */
        //? ** find index of '@'***/
        atIndex = email.find("@");

        //? ** extract ***/
        if (atIndex != string::npos)
        {
            username = email.substr(0, atIndex);
        }

        //? ** validate ***/
        if (checkUserName(username) == false)
        {
            invalidEmail(email);
            cout << "Username invalid, must be alphanumeric "
                 << endl;
            continue; //^ if username not valid then continue and move to next iteration
        }

        //& ******************** HOSTNAME ****************** */
        //? ** find ***/
        dotIndex = email.find(".");
        //? ** extract ***/
        if (dotIndex != string::npos)
        {
            host = email.substr(atIndex + 1, dotIndex - atIndex - 1);
        }

        //? ** validate ***/
        if (checkHost(host) == false)
        {
            invalidEmail(email);
            cout << "Host name must be genuine "
                 << endl;
            continue; //^ if host not valid then continue and move to next iteration
        }

        //& ************** DOMAIN **********************/

        //? ** extract ***/
        domain = email.substr(dotIndex);

        //? ** check ***/
        if (checkDomain(domain) == false)
        {
            invalidEmail(email);
            cout << "Domain invalid. Must be \".com or \".edu "
                 << endl;
            continue; //^ if domain not valid then continue and move to next iteration
        }

        //* once the email is validated, we will store it in our vector of classes
        VALIDATOR user(username, host, domain); // creating an object of VALIDATOR
        valid_email_store.push_back(user);
    }

    //& ******* WRITE VALID EMAILS ******* */
    cout << "\n****** WRITE Valid emails *******\n";
    for (auto value : valid_email_store)
        value.writeData(&fout);

    cout << "\nFILE WRITTEN SUCCESSFULLY\n\n";

    //& close files
    fin.close();
    fout.close();

    return EXIT_SUCCESS;
}
